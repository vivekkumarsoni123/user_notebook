import React from 'react'   //just write <rafce> to get the format of the page
// import noteContext from '../Context/notes/noteContext'

const About = ()=> {
  // const a = useContext(noteContext);
  // useEffect(()=>{
  //   a.update();
  //   // eslint-disable-next-line
  // }, [])
  return (
    <div>
      {/* {a.state.name} */}
      <h1>This is About page</h1> 
    </div>
  )
}

export default About;
